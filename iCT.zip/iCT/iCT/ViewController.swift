//
//  ViewController.swift
//  iCT
//
//  Created by Khushiii on 04/05/23.
//

import UIKit
import CoreData

class ViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let department = ["Sales","Manager","IT"]
    
    
    @IBOutlet weak var date: UIDatePicker!
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        picker.delegate = self
        picker.dataSource = self
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return department[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return department.count
    }
    

    @IBAction func insert(_ sender: Any) {
        
        let newitem = NSEntityDescription.insertNewObject(forEntityName: "Data", into: context)
        
        newitem.setValue(name.text, forKey: "name")
        newitem.setValue(Int(age.text!), forKey: "age")
        
        let deptindex = picker.selectedRow(inComponent: 0)
        let dept = department[deptindex]
       
        newitem.setValue(dept, forKey: "dept")
      
        newitem.setValue(date.date, forKey: "dob")
        
        do{
            try! context.save()
            print("Insert")
            
            let fetch = NSFetchRequest<Data>(entityName: "Data")
            do{
               var data = [Data]()
                data =  try! context.fetch(fetch)
                for i in data{
                    print(i.name!)
                    print(i.age)
                    print(i.dept!)
                    print(i.dob!)
                    print("-----------------------------")
                }
            }
        }

        
    }
}

