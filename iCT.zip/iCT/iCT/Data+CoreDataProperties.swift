//
//  Data+CoreDataProperties.swift
//  iCT
//
//  Created by Khushiii on 04/05/23.
//
//

import Foundation
import CoreData


extension Data {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Data> {
        return NSFetchRequest<Data>(entityName: "Data")
    }

    @NSManaged public var age: Int64
    @NSManaged public var dept: String?
    @NSManaged public var dob: Date?
    @NSManaged public var name: String?

}

extension Data : Identifiable {

}
