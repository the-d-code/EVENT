//
//  Data+CoreDataClass.swift
//  iCT
//
//  Created by Khushiii on 04/05/23.
//
//

import Foundation
import CoreData

@objc(Data)
public class Data: NSManagedObject {

}
