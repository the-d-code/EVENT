//
//  DBHelper.swift
//  iCT
//
//  Created by Khushiii on 04/05/23.
//

import Foundation
import UIKit
import CoreData

class DBHelper {
    
    static var instance = DBHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    func getdata() ->[Data]{
        var data = [Data]()
        let fetch = NSFetchRequest<Data>(entityName: "Data")
        do{
            
            data =  try! context.fetch(fetch)
        }
        
        return data
    }
}
