//
//  ListViewController.swift
//  iCT
//
//  Created by Khushiii on 04/05/23.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
   
    var data = [Data]()


    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        data = DBHelper.instance.getdata()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath)as! TableViewCell
        cell.name.text = data[indexPath.row].name
        cell.age.text = String(data[indexPath.row].age)
        cell.dept.text = data[indexPath.row].dept

        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        
        let dateOfBirth = data[indexPath.row].dob
        cell.dob.text = dateFormatter.string(from: dateOfBirth!)
        
        
        return cell
        
    }
   

}
