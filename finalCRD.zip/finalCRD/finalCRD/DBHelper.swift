//
//  DBHelper.swift
//  finalCRD
//
//  Created by Khushiii on 28/04/23.
//

import Foundation
import CoreData
import UIKit

class DBHelper{
    
    static var instance = DBHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    func getData() -> [Final]{
        
        var final = [Final]()
        let fetch = NSFetchRequest<Final>(entityName: "Final")
        
        do{
            final = try! context.fetch(fetch)
        }
        return final
    }
    
    
    func delete(index: Int) -> [Final]{
        var data = getData()
        context.delete(data[index])
        data.remove(at: index)
        do
        {
            try! context.save()
        }
        return data
    }
}
