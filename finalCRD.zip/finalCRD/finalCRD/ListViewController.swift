//
//  ListViewController.swift
//  finalCRD
//
//  Created by Khushiii on 28/04/23.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var final = [Final]()
    
    @IBOutlet weak var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        final = DBHelper.instance.getData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell",for: indexPath)as! TableViewCell
        
        cell.namelbl.text = final[indexPath.row].name
        cell.agelbl.text = String(final[indexPath.row].age)
        cell.deptlbl.text = final[indexPath.row].department
        
        let dateformat = DateFormatter()
        dateformat.dateFormat = "dd/MM/yyyy"
        let dob = final[indexPath.row].dob
        if let dob = dob{
            cell.doblbl.text = dateformat.string(from: dob)
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle : UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
    
        if editingStyle == .delete
        {
            final = DBHelper.instance.delete(index: indexPath.row)
            self.tableview.deleteRows(at: [indexPath], with: .automatic)
            
        }
         
    }
    
}
