//
//  Final+CoreDataClass.swift
//  finalCRD
//
//  Created by Khushiii on 28/04/23.
//
//

import Foundation
import CoreData

@objc(Final)
public class Final: NSManagedObject {

}
