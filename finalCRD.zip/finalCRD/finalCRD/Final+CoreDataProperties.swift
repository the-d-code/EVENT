//
//  Final+CoreDataProperties.swift
//  finalCRD
//
//  Created by Khushiii on 28/04/23.
//
//

import Foundation
import CoreData


extension Final {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Final> {
        return NSFetchRequest<Final>(entityName: "Final")
    }

    @NSManaged public var name: String?
    @NSManaged public var age: Int64
    @NSManaged public var department: String?
    @NSManaged public var dob: Date?

}

extension Final : Identifiable {

}
