//
//  ViewController.swift
//  finalCRD
//
//  Created by Khushiii on 28/04/23.
//

import UIKit
import CoreData
class ViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
   
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    let department = ["Sales","Manager","IT"]

    @IBOutlet weak var datepk: UIDatePicker!
    @IBOutlet weak var pickerviewdept: UIPickerView!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        pickerviewdept.delegate = self
        pickerviewdept.dataSource = self
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return department[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return department.count
    }

    @IBAction func add(_ sender: Any) {
        
        guard let name = name.text , !name.isEmpty else{
            
            let alert = UIAlertController(title: "Name Can't be Empty", message: "Enter Name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default,handler: nil))
            present(alert, animated: true,completion: nil)
            
            return
        }
        guard let agetxt = age.text , let agef = Int(agetxt), agef > 0  else{
            
            let alert = UIAlertController(title: "Age must a digit only", message: "Enter proper age", preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "OK", style: .default,handler: nil))
            
            present(alert, animated: true,completion: nil)
            return
        }
        
        let deptindex = pickerviewdept.selectedRow(inComponent: 0)
        let dept = department[deptindex]
        
        let newitem = NSEntityDescription.insertNewObject(forEntityName: "Final", into: context)
        
        newitem.setValue(name, forKey: "name")
        newitem.setValue(agef, forKey: "age")
        newitem.setValue(dept, forKey: "department")
        newitem.setValue(datepk.date, forKey: "dob")
        
        do{
            try! context.save()
            print("Inserted!!")
        }
    }
}

