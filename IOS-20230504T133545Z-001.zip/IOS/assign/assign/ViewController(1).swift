//
//  ViewController.swift
//  assign
//
//  Created by mscit on 2/6/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textBox: UITextField!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func click(_ sender: Any) {
      
        label.text = "hello "+textBox.text!
    }
    
}

