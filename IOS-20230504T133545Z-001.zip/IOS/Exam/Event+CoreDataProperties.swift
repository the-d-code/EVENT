//
//  Event+CoreDataProperties.swift
//  Exam
//
//  Created by mscit on 4/11/23.
//
//

import Foundation
import CoreData


extension Event {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Event> {
        return NSFetchRequest<Event>(entityName: "Event")
    }

    @NSManaged public var elocation: String?
    @NSManaged public var edate: String?
    @NSManaged public var eid: String?
    @NSManaged public var etype: String?

}

extension Event : Identifiable {

}
