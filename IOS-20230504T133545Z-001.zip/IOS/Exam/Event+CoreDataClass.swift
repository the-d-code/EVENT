//
//  Event+CoreDataClass.swift
//  Exam
//
//  Created by mscit on 4/11/23.
//
//

import Foundation
import CoreData

@objc(Event)
public class Event: NSManagedObject {

}
