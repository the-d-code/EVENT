//
//  DBHelper.swift
//  Exam
//
//  Created by mscit on 4/8/23.
//

import Foundation
import Foundation
import CoreData
import UIKit
class DBHelper{
 
static var instance = DBHelper()
let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

//display
func getEvent() -> [Event]{

    var event = [Event]()
    let fetch = NSFetchRequest<NSManagedObject>(entityName: "Event")
    do{
        event = try context.fetch(fetch) as! [Event]
    }
    catch{

        print("Error")

    }
    return event

}

//delete
func deleteData(index:Int) -> [Event]{

    var event = getEvent()
    context.delete(event[index])
    event.remove(at: index)

    do{
        try! context.save()
        print("Data deleted !!")
    }catch{
        print("Can not delete data")
    }
    return event
}

}
