//
//  Employee+CoreDataProperties.swift
//  Exam
//
//  Created by mscit on 4/8/23.
//
//

import Foundation
import CoreData


extension Employee {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Employee> {
        return NSFetchRequest<Employee>(entityName: "Employee")
    }

    @NSManaged public var eid: String?
    @NSManaged public var etype: String?
    @NSManaged public var edate: String?
    @NSManaged public var elocation: String?

}

extension Employee : Identifiable {

}
