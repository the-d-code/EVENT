//
//  ViewController.swift
//  Exam
//
//  Created by mscit on 4/8/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    
    @IBOutlet weak var txtid: UITextField!
    
    
    @IBOutlet weak var txttype: UITextField!
    
    @IBOutlet weak var txtdate: UITextField!
    
    @IBOutlet weak var txtlocation: UITextField!
    
    
    /*
    @IBOutlet weak var txtlocation: UITextField!
    @IBOutlet weak var txtdate: UITextField!
    @IBOutlet weak var txttype: UITextField!
    @IBOutlet weak var txtid: UITextField!
 */
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
    }
    
    @IBAction func btnadd(_ sender: Any)
    {
      let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

           
               let newdata = NSEntityDescription.insertNewObject(forEntityName: "Event", into: context)
                newdata.setValue(txtid.text, forKey: "eid")
                newdata.setValue(txttype.text, forKey: "etype")
                newdata.setValue(txtdate.text, forKey: "edate")
        newdata.setValue(txtlocation.text, forKey: "elocation")
            
                do{
                  try! context.save()
                    print("Done record")
                }
            
        
    }
    
   
    
}

