//
//  Employee+CoreDataClass.swift
//  Exam
//
//  Created by mscit on 4/8/23.
//
//

import Foundation
import CoreData

@objc(Employee)
public class Employee: NSManagedObject {

}
