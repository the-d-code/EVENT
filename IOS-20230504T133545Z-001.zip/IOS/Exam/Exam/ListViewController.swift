//
//  ListViewController.swift
//  Exam
//
//  Created by mscit on 4/8/23.
//

import UIKit
import CoreData
class ListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
var event = [Event]()


    @IBOutlet weak var tableview: UITableView!
    
override func viewDidLoad() {
    super.viewDidLoad()

    event = DBHelper.instance.getEvent()

}

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return event.count
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

    var cell = tableview.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell

    cell.lblid.text = event[indexPath.row].eid
    cell.lbltype.text = event[indexPath.row].etype
    cell.lbldate.text = event[indexPath.row].edate
    cell.lbllocation.text = event[indexPath.row].elocation
    

    return cell
}

func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 120
    
}


//delete
func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
    true
}

func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {

    if editingStyle == .delete{
        event = DBHelper.instance.deleteData(index: indexPath.row)
        self.tableview.deleteRows(at: [indexPath], with: .automatic)
    }
}
}
