//
//  TableViewCell.swift
//  Exam
//
//  Created by mscit on 4/8/23.
//

import UIKit

class TableViewCell: UITableViewCell {
/*
    @IBOutlet weak var lbllocation: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var lbltype: UILabel!
    @IBOutlet weak var lblid: UILabel!
 */
 
    
    
    @IBOutlet weak var lbllocation: UILabel!
    
    @IBOutlet weak var lbldate: UILabel!
    
    @IBOutlet weak var lbltype: UILabel!
    
    
    @IBOutlet weak var lblid: UILabel!
    
    
    
 override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
